import pandas as pd
import collections
import os

class SelectR:
    """
    SelectR object contains methods to read and parse
    the data from a folder with data in the SelectR format.
    """ 
    
    def __init__(self, folder = None):
        if folder != None:
            self.folder = folder
            self.files = self.get_files(folder)
            self.df = self.to_df(self.files)
        
    def get_files(self, folder):
        """
        Finds *.SE1 files in the folder
        
        Parameters
        ----------
        folder : str
            A path containing SE1 files.

        Returns
        -------
        files : list
            A list of files with the SE1 file extension.

        """
        files=[]
        address = folder
        for i in os.listdir(address):
            file_ext = os.path.splitext(i)[-1]
            if (file_ext != '.SE1'):
                continue
            files.append(address+'/'+i)
        assert files != [], "no *.SE1 files found"
        return files
        
    def parse(self, file):
        df=[]
        sections={}
        currentsection=''
        with open(file, encoding='utf-8', errors='ignore') as fileObject:
            for line in fileObject:
                line=line.strip()
                if ((line.startswith('[')) and (line.endswith(']'))) or (('*End of Payload*' in line) and (currentsection!='')):
                    if sections!={}:
                        df.append(sections)
                    else: pass
                    currentsection=line
                    sections={'Section': line.replace('[','').replace(']','').upper()}
                else:
                    if (currentsection!='') and ('=' in line):
                        value=line.split('=')
                        sections[value[0].upper()]=value[-1]
                    else: continue
        return df
    
    def combine(self, list_):
        combine=collections.defaultdict(list)
        for i in list_:
            combine[i['Section']].append(i)
        for key in combine:
            df_output=[]
            for j in combine[key]:
                del j['Section']
                df_output.append(pd.DataFrame.from_dict(j, orient='index').transpose())
            df_output=pd.concat(df_output).fillna('N/A')
            df_output.drop_duplicates(list(df_output), inplace=True)
        return df_output

    def to_df(self, SE1_files):
        for file in SE1_files:
            df = self.parse(file)
            df = self.combine(df)
        return df
