# SelectR

This Python project will read and parse data in the SelectR format.

## About SelectR

The Standard Electronic Client Transaction Reporting System (SelectR) data format is a structure for various dealers in securities across Canada to provide information on individuals and trades to securities regulator authorities and regulation services providers.

## Installation

Execute the following terminal command in the same directory that the .whl file is stored in:

`pip install OSC_SelectR-{version_number}-py3-none-any.whl`

Replace {version_number} with the actual version number of the file you have.

E.g.

`pip install OSC_SelectR-0.1.1-py3-none-any.whl`

## Usage

You may instantiate a `SelectR` object with the Python command:

```
from selectr import SelectR
foo = SelectR()
```

4 methods are exposed when instantiated without the `folder` argument:

{insert methods}

Alternatively, you may also instantiate a `SelectR` object with a `folder` argument:

```
bar = SelectR("./path/to/.se1_files")
```

Doing so will expose 3 additional data objects:

1. folder - confirms the folder
2. files - a list of detected .SE1 files
3. df - a list of parsed data frames from the .SE1 files

